<?php
/**
* 2007-2022 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2022 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

if (file_exists(_PS_MODULE_DIR_. 'gcfas400synch/vendor/autoload.php')) {
    require_once _PS_MODULE_DIR_.  'gcfas400synch/vendor/autoload.php';
}

use Juba\Gcfas400synch\Classes\ManagerFile;

class Gcfas400synch extends Module
{

    /**
     * @param array $tabs
     */
    public $tabs = [];

    /**
     * @param Juba\Gcfas400synch\Repository $repository
     */
    protected $repository;
    
    protected $config_form = "config-global";

    public function __construct()
    {
        $this->name = 'gcfas400synch';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Juba';
        $this->need_instance = 0;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;
        $this->repository = new Juba\Gcfas400synch\Repository($this);

        parent::__construct();

        $this->displayName = $this->l('Set product quantity and update order state');
        $this->description = $this->l('This module allow you to set product quantities and update order state');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        return parent::install() && $this->repository->install();
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->repository->uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $process = $this->postProcess();
        
        $this->context->smarty->assign(
            array(
                'module_dir' => $this->_path,
                'config_form' => $this->config_form,
                'form' => $this->renderFormSave(),
                'import_form' => $this->renderFormImport(),
            )
        );

        return $process.$this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderFormSave()
    {
        $form = new Juba\Gcfas400synch\Utils\FormForm($this);
        $form->setShowToolbar(false)
            ->setTable($this->table)
            ->setModule($this)
            ->setDefaultFromLanguage($this->context->language->id)
            ->setAllowEmployeFromLang(Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0))
            ->setIdentifier($this->identifier)
            ->setSubmitAction('submitConfigFormSave')
            ->setCurrentIndex($this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name)
            ->setToken(Tools::getAdminTokenLite('AdminModules'))
            ->setTplVar([
                'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
                'languages' => $this->context->controller->getLanguages(),
                'id_language' => $this->context->language->id,
            ])
            ->addField(
                array(
                    'type' => 'file',
                    'label' => $this->l('Stock produit'),
                    'name' => 'GCFAS400SYNCH_SAVE_PRODUCT_QTY',
                ),
            )
            ->addField(
                array(
                    'type' => 'file',
                    'label' => $this->l('Status de commande'),
                    'name' => 'GCFAS400SYNCH_SAVE_ORDER_STATE',
                ),
            )
            ->setLegend([
                'title' => $this->l('Store files'),
                'icon' => 'icon-cogs',
            ])->setSubmit([
                'title' => $this->l('Save'),
            ])
        ;

        return $form->make();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderFormImport()
    {
        $form = new Juba\Gcfas400synch\Utils\FormForm($this);
        $form->setShowToolbar(false)
            ->setTable($this->table)
            ->setModule($this)
            ->setDefaultFromLanguage($this->context->language->id)
            ->setAllowEmployeFromLang(Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0))
            ->setIdentifier($this->identifier)
            ->setSubmitAction('submitConfigFormImport')
            ->setCurrentIndex($this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name)
            ->setToken(Tools::getAdminTokenLite('AdminModules'))
            ->setTplVar([
                'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
                'languages' => $this->context->controller->getLanguages(),
                'id_language' => $this->context->language->id,
            ])
            ->addField(
                array(
                    'type' => 'file',
                    'label' => $this->l('Stock produit'),
                    'name' => 'GCFAS400SYNCH_IMPORT_PRODUCT_QTY',
                ),
            )
            ->addField(
                array(
                    'type' => 'file',
                    'label' => $this->l('Status de commande'),
                    'name' => 'GCFAS400SYNCH_IMPORT_ORDER_STATE',
                ),
            )
            ->setLegend([
                'title' => $this->l('Import files'),
                'icon' => 'icon-cogs',
            ])->setSubmit([
                'title' => $this->l('Save'),
            ])
        ;

        return $form->make();
    }

   

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'GCFAS400SYNCH_IMPORT_PRODUCT_QTY' => '',
            'GCFAS400SYNCH_IMPORT_ORDER_STATE' => '',
            'GCFAS400SYNCH_SAVE_PRODUCT_QTY' => '',
            'GCFAS400SYNCH_SAVE_ORDER_STATE' => '',
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        if(Tools::isSubmit('submitConfigFormSave')){
            $response = [];
            $return = "";

            if(isset($_FILES['GCFAS400SYNCH_SAVE_PRODUCT_QTY']) && $_FILES['GCFAS400SYNCH_SAVE_PRODUCT_QTY']['size']) {
                $response[] = ManagerFile::saveFile($_FILES['GCFAS400SYNCH_SAVE_PRODUCT_QTY'], ManagerFile::FOLDER_STOCK);
                
            }
            if(isset($_FILES['GCFAS400SYNCH_SAVE_ORDER_STATE']) && $_FILES['GCFAS400SYNCH_SAVE_ORDER_STATE']['size']) {
                $response[] = ManagerFile::saveFile($_FILES['GCFAS400SYNCH_SAVE_ORDER_STATE'], ManagerFile::FOLDER_EXPEDITION);
            }

            if(!empty($response)) {
                foreach($response as $res){
                    if($res->getResponse()) {
                        $return .= $this->displayConfirmation($res->getMessage());
                    }
                    else {
                        $return .= $this->displayError($res->getMessage());
                    }
                }
            }
            
            return $return;
        } elseif(Tools::isSubmit('submitConfigFormImport')) {
            $this->config_form = "config-import";

            $response = [];
            $return = "";

            if(isset($_FILES['GCFAS400SYNCH_IMPORT_PRODUCT_QTY']) && $_FILES['GCFAS400SYNCH_IMPORT_PRODUCT_QTY']['size']) {
                $a = ManagerFile::importFile($_FILES['GCFAS400SYNCH_IMPORT_PRODUCT_QTY'], ManagerFile::FOLDER_STOCK);
              
                if(is_array($a)) {
                    $response = array_merge($response, $a);
                } else {
                    $response[] = $a;
                } 
            }
            if(isset($_FILES['GCFAS400SYNCH_IMPORT_ORDER_STATE']) && $_FILES['GCFAS400SYNCH_IMPORT_ORDER_STATE']['size']) {
                $a = ManagerFile::importFile($_FILES['GCFAS400SYNCH_IMPORT_ORDER_STATE'], ManagerFile::FOLDER_EXPEDITION);
                
                if(is_array($a)) {
                    $response = array_merge($response, $a);
                } else {
                    $response[] = $a;
                }
            }

            /*dump($response);
            dump($_FILES);
            die;*/

            if(!empty($response)) {
                foreach($response as $res){
                    if($res->getResponse()) {
                        $return .= $this->displayConfirmation($res->getMessage());
                    }
                    else {
                        $return .= $this->displayError($res->getMessage());
                    }
                }
            }
            return $return;
        }
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }
}
