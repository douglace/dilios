<?php

namespace Juba\Gcfas400synch\Classes;

class Response {
    
    /**
     * @var string
     */
    private $message;

    /**
     * @var bool
     */
    private $response;

    /**
    * @param string $message
    * @param bool $response
    */
    public function __construct($message = "", $response = true)
    {
        $this->message = $message;
        $this->response = $response;
    }

    public function getMessage() {
        return $this->message;
    }

    public function getResponse() {
        return $this->response;
    }
}