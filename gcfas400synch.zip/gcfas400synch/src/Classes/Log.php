<?php

namespace Juba\Gcfas400synch\Classes;

class Log {
    
    const TYPE_STOCK = "stocks";

    const TYPE_EXPEDITION = "expeditions";

    /**
     * @return string
     */
    private function getLogStockDir() {
        return dirname(dirname(__DIR__)).DIRECTORY_SEPARATOR.'traitements/logs/stock/';
    }

    /**
     * @return string
     */
    private function getLogExpeditionDir() {
        return dirname(dirname(__DIR__)).DIRECTORY_SEPARATOR.'traitements/logs/expeditions/';
    }

    /**
     * @var string
     */
    public $message;

    /**
     * @var string
     */
    public $type;

    /**
    * @param string $message
    * @param string $type
    */
    public function __construct($message, $type)
    {
        $this->message = $message;
        $this->type = $type;
    }


    private function getFileName() {
        if($this->type === self::TYPE_STOCK) {
            return $this->getLogStockDir().date('Ymd').'-log.txt';
        }
        return $this->getLogExpeditionDir().date('Ymd').'-log.txt';
    }

    /**
    * @return bool
    */
    public function write() {
        $filename = $this->getFileName();
        if(file_exists($filename)) {
            $fileHandle = fopen($filename, 'a');
        } else {
            $fileHandle = fopen($filename, 'w');
        }
        fwrite($fileHandle, $this->message." {date: ".date('Y-m-d H:i:s')."} "." ".PHP_EOL);
        fclose($fileHandle);
        return true;
    }

    /**
    * @param string $message
    * @param string $type
    * @return bool
    */
    public static function create($message, $type){
        return (new Log($message, $type))->write();
    }
}