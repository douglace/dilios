<?php

namespace Juba\Gcfas400synch\Classes;

use Db;
use Order;
use Product;
use Shop;
use StockAvailable;

class ManagerFile {
    
    const FOLDER_STOCK = 'stock';

    const FOLDER_EXPEDITION = 'expeditions';

    /**
     * @return string
     */
    public static function getInputDir() {
        return dirname(dirname(__DIR__)).DIRECTORY_SEPARATOR.'traitements/input/';
    }

    /**
     * @return string
     */
    public static function getArchiveDir() {
        return dirname(dirname(__DIR__)).DIRECTORY_SEPARATOR.'traitements/archive/';
    }

    /**
     * @param array $file
     * @param string $direction
     * @return Response
     */
    public static function saveFile($file, $direction){
        try {
            if($file['error'] == UPLOAD_ERR_OK){
                $name = $file['name'];
                $exp = explode('.', $name);
                $ext = strtolower(end($exp));
                $tmpName = $file['tmp_name'];
                if(!self::isCSVFile($file)) {
                    return new Response("Bad file ".$name.'.'.$ext.". Please use csv file", false);
                }
                
                if(move_uploaded_file($tmpName, self::getInputDir().$direction. DIRECTORY_SEPARATOR .$name)) {
                    return new Response("File ".$name.'.'.$ext." successfully saved", true);
                }
                return new Response("An error occurred while saving file ".$name.'.'.$ext, false);
            } 
            
            return new Response("Bad file $direction", false);
        }catch(\Exception $e){
            return new Response($e->getMessage(), false);
        }
    }
    
    private static function importData($data, $direction) {
        if($direction === self::FOLDER_STOCK) {
            $shop_ref = trim($data[0]);
            $product_ref = trim($data[1]);
            $qty = (int)$data[2];

            if($qty < 0) {
                Log::create("SHOP REF : ".$shop_ref." - PRODUCT REF ".$product_ref." - QTY : ".$qty." (Negative quantity)", Log::TYPE_STOCK);
            } else {
                $update = self::updateProductStock(
                    $shop_ref, 
                    $product_ref, 
                    $qty
                );
                
                if(!$update) {
                    Log::create("SHOP REF : ".$shop_ref." - PRODUCT REF ".$product_ref." - QTY : ".$qty, Log::TYPE_STOCK);
                };
            }
        } elseif($direction === self::FOLDER_EXPEDITION) {
            $id_state = trim($data[6]);
            $ref_order = trim($data[8]);
            $orders = Order::getByReference($ref_order);
            $id_state = 2;

            if($orders->count()) {
                foreach($orders as $order) {
                    $order->setCurrentState($id_state);
                }
            } else {
                Log::create("Orders ref : [".$ref_order."] doesn't exist.", Log::TYPE_EXPEDITION);
            }

        }

        return true;
    }

    /**
     * @param array $file
     * @param string $direction
     * @return Response
     */
    public static function importFile($file, $direction) {
        try {
            if($file['error'] == UPLOAD_ERR_OK){

                if(!self::isCSVFile($file)) {
                    return new Response("Bad file ".$file['name'].". Please use csv file", false);
                }

                if($handle = fopen($file['tmp_name'], "r")) {
                    $headers = fgetcsv($handle, 1000, ";");
                    set_time_limit(0);
                    while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) 
                    {
                        self::importData($data, $direction);
                    }
                }
                
                fclose($handle);
                return [
                    self::archiveFile($file, $direction),
                    new Response("File ".$file['name']." successfully imported", true)
                ];
            }

        }catch(\Exception $e){
            return new Response($e->getMessage(), false);
        }
    }

    private static function isCSVFile($file) {
        $name = $file['name'];
        $exp = explode('.', $name);
        $ext = strtolower(end($exp));
        if($ext != 'csv') {
            return false;
        }
        return true;
    }

    /**
     * @param string $ref_shop
     * @param string $ref_product
     * @param int $qty
     * @return bool
     */
    public static function updateProductStock($ref_shop, $ref_product, $qty) {
        $id_shop = self::getShopByReference($ref_shop);
        if(!$id_shop) return false;

        
        $id_product = Product::getIdByReference($ref_product);
        if(!$id_shop) return false;

        StockAvailable::setQuantity(
            $id_product,
            0,
            (int)$qty,
            $id_shop
        );
        
        return true;
    }

    /**
     * @param string $reference
     * @return int|bool
     */
    public static function getShopByReference($reference) {
        return Db::getInstance()->getValue('SELECT id_shop FROM `'._DB_PREFIX_.'shop` where reference="'.$reference.'"');
    }

    /**
     * @param array $file
     * @param string $direction
     * @return Response
     */
    public static function archiveFile($file, $direction) {
        try {
            if($file['error'] == UPLOAD_ERR_OK){
                $name = $file['name'];
                $exp = explode('.', $name);
                $ext = strtolower(end($exp));
                $tmpName = $file['tmp_name'];
                if(!self::isCSVFile($file)) {
                    return new Response("Bad file ".$name.'.'.$ext.". Please use csv file", false);
                }
                
                if(move_uploaded_file($tmpName, self::getArchiveDir().$direction. DIRECTORY_SEPARATOR .date('Ymd').'.'.$ext)) {
                    return new Response("File ".$name.'.'.$ext." has been successfully archived", true);
                }
                return new Response("An error occurred while archive file ".$name.'.'.$ext, false);
            }
        }catch(\Exception $e){
            return new Response($e->getMessage(), false);
        }
    }

    /**
     * import saved file
     */
    public static function executeFileSaved(){
        $stock = self::getInputDir().self::FOLDER_STOCK;
        $exeditions = self::getInputDir().self::FOLDER_EXPEDITION;

        try{
            if ($handleDir = opendir($stock)) {
                while (false !== ($entry = readdir($handleDir))) {
                    if ($entry != "." && $entry != "..") {
                       $file = $stock.DIRECTORY_SEPARATOR.$entry;
                       if($handle = fopen($file, "r")) {
                            $headers = fgetcsv($handle, 1000, ";");
                            set_time_limit(0);
                            while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) 
                            {
                                self::importData($data, self::FOLDER_STOCK);
                            }
                        }
                        fclose($handle);
                        if(!rename($file, self::getArchiveDir().self::FOLDER_STOCK. DIRECTORY_SEPARATOR .date('Ymd-Hi')."-cron.csv")) {
                            Log::create("Unable to import file [".$file."] by cron ", Log::TYPE_STOCK);
                        }
                    }
                }
                closedir($handleDir);
            }
        }catch(\Exception $e) {
            Log::create($e->getMessage(), Log::TYPE_STOCK);
        }

        try{
            if ($handleDir = opendir($exeditions)) {
                while (false !== ($entry = readdir($handleDir))) {
                    if ($entry != "." && $entry != "..") {
                       $file = $exeditions.DIRECTORY_SEPARATOR.$entry;
                       
                       if($handle = fopen($file, "r")) {
                            $headers = fgetcsv($handle, 1000, ";");
                            set_time_limit(0);
                            while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) 
                            {
                                self::importData($data, self::FOLDER_EXPEDITION);
                            }
                        }
                        fclose($handle);
                        if(!rename($file, self::getArchiveDir().self::FOLDER_EXPEDITION. DIRECTORY_SEPARATOR .date('Ymd-Hi')."-cron.csv")) {
                            Log::create("Unable to import file [".$file."] by cron ", Log::TYPE_EXPEDITION);
                        }
                    }
                }
                closedir($handleDir);
            }
        }catch(\Exception $e) {
            Log::create($e->getMessage(), Log::TYPE_EXPEDITION);
        }
        
    }
}